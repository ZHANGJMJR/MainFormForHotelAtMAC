using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Transactions;
using Dapper;
using log4net;
using log4net.Config;
using Oracle.ManagedDataAccess.Client;
using MySql.Data.MySqlClient;
using System.Reflection;
using System.IO;

// =============== 主表 GuestCheckHist ===============
public class GuestCheckHist
{
    public long guestcheckid { get; set; }
    public DateTime busdate { get; set; }
    public long locationid { get; set; }
    public long revenuecenterid { get; set; }
    public long checkNum { get; set; }
    public DateTime openDateTime { get; set; }
    public decimal checkTotal { get; set; }
    public long numItems { get; set; }
    public string firstName { get; set; }
    public string lastName { get; set; }
}

// =============== 从表 GuestCheckDetailHist ===============
public class GuestCheckDetailHist
{
    public long guestcheckid { get; set; }  // 关联主表
    public long itemid { get; set; }
    public string itemname { get; set; }
    public decimal itemprice { get; set; }
    public int quantity { get; set; }
}

public class Dlt
{
    private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
    private static readonly string oracleConnStr = "User Id=sys;Password=Orcl$1mph0ny;Data Source=172.16.139.12:1521/mcrspos;DBA Privilege=SYSDBA;";
    private static readonly string mysqlConnStr = "Server=127.0.0.1;Port=3306;Database=hotel;User=root;Password=root;";

    static Dlt()
    {
        XmlConfigurator.Configure(new FileInfo("log4net.config"));
    }

    public void SyncData()
    {
        log.Info("=== 开始同步数据 ===");

        using (var oracleConn = new OracleConnection(oracleConnStr))
        using (var mysqlConn = new MySqlConnection(mysqlConnStr))
        {
            try
            {
                oracleConn.Open();
                log.Info("Oracle 数据库连接成功");

                mysqlConn.Open();
                log.Info("MySQL 数据库连接成功");

                string currentDateStr = "2024-07-01";

                // ========================== 1️⃣ 同步主表数据 ==========================
                string masterQuery = @"
                SELECT gch.guestCheckID as guestCheckID, gch.openBusinessDate as busDate,
                       gch.locationID as locationid, gch.revenuecenterid as revenuecenterid,
                       gch.checknum AS checkNum, 
                       TO_DATE(TO_CHAR(gch.opendatetime, 'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS') AS openDateTime, 
                       gch.checktotal AS checkTotal,
                       gch.numitems AS numItems, e.firstname AS firstName, e.lastname AS lastName 
                FROM guest_check_hist gch  
                LEFT JOIN employee e ON gch.employeeid = e.employeeid 
                WHERE gch.organizationID = 10260 
                  AND gch.locationID = 2041 
                  AND gch.openbusinessdate >= TO_DATE(:currentDateStr, 'YYYY-MM-DD')
                  AND gch.closebusinessdate <= TO_DATE(:currentDateStr, 'YYYY-MM-DD')";

                var masterRecords = oracleConn.Query<GuestCheckHist>(masterQuery, new { currentDateStr }).ToList();

                if (!masterRecords.Any())
                {
                    log.Warn("主表未查询到数据");
                    return;
                }

                log.Info($"从 Oracle 获取 {masterRecords.Count} 条主表记录");

                string masterInsertQuery = @"
                INSERT INTO guestcheck 
                  (guestCheckID, busDate, locationid, revenuecenterid, checkNum, openDateTime, checkTotal, numItems, firstName, lastName) 
                VALUES 
                  (@guestCheckID, @busDate, @locationid, @revenuecenterid, @checkNum, @openDateTime, @checkTotal, @numItems, @firstName, @lastName);";

                using (var transaction = new TransactionScope())
                {
                    mysqlConn.Execute(masterInsertQuery, masterRecords);
                    transaction.Complete();
                }

                log.Info("主表数据同步完成");

                // ========================== 2️⃣ 同步从表数据 ==========================
                string detailQuery = @"
                SELECT gcd.guestCheckID as guestcheckid, 
                       gcd.itemid as itemid, 
                       i.itemname as itemname, 
                       gcd.itemprice as itemprice, 
                       gcd.quantity as quantity
                FROM guest_check_detail_hist gcd
                JOIN item i ON gcd.itemid = i.itemid
                WHERE gcd.guestCheckID IN :guestCheckIDs";

                var guestCheckIDs = masterRecords.Select(x => x.guestcheckid).ToList();
                var detailRecords = oracleConn.Query<GuestCheckDetailHist>(detailQuery, new { guestCheckIDs }).ToList();

                if (!detailRecords.Any())
                {
                    log.Warn("从表未查询到数据");
                    return;
                }

                log.Info($"从 Oracle 获取 {detailRecords.Count} 条从表记录");

                string detailInsertQuery = @"
                INSERT INTO guestcheckdetail 
                  (guestCheckID, itemid, itemname, itemprice, quantity) 
                VALUES 
                  (@guestcheckid, @itemid, @itemname, @itemprice, @quantity);";

                using (var transaction = new TransactionScope())
                {
                    mysqlConn.Execute(detailInsertQuery, detailRecords);
                    transaction.Complete();
                }

                log.Info("从表数据同步完成");
            }
            catch (Exception ex)
            {
                log.Error("数据同步失败: " + ex.Message, ex);
            }
            finally
            {
                if (oracleConn.State == ConnectionState.Open)
                {
                    oracleConn.Close();
                    log.Info("Oracle 数据库连接关闭");
                }
                if (mysqlConn.State == ConnectionState.Open)
                {
                    mysqlConn.Close();
                    log.Info("MySQL 数据库连接关闭");
                }
            }
        }

        log.Info("=== 数据同步完成 ===");
    }
}
