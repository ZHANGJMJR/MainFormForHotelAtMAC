using System;
using System.Data;
using System.Transactions;
using Dapper;
using log4net;
using log4net.Config;
using Oracle.ManagedDataAccess.Client;
using MySql.Data.MySqlClient;
using System.Reflection;
using System.IO;

public class GuestCheckHist
{
    public long guestcheckid { get; set; }
    public DateTime busdate { get; set; }
    public long locationid { get; set; }
    public long revenuecenterid { get; set; }
    public long checkNum { get; set; }
    public DateTime openDateTime { get; set; }
    public decimal checkTotal { get; set; }
    public long numItems { get; set; }
    public string firstName { get; set; }
    public string lastName { get; set; }
}

public class Dlt
{
    private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

    private static readonly string oracleConnStr = "User Id=sys;Password=Orcl$1mph0ny;Data Source=172.16.139.12:1521/mcrspos;DBA Privilege=SYSDBA;";
    private static readonly string mysqlConnStr = "Server=127.0.0.1;Port=3306;Database=hotel;User=root;Password=root;";

    static Dlt()
    {
        XmlConfigurator.Configure(new FileInfo("log.config"));
    }

    public void SyncData()
    {
        log.Info("=== 开始同步数据 ===");
        try
        {
            using (var oracleConn = new OracleConnection(oracleConnStr))
            using (var mysqlConn = new MySqlConnection(mysqlConnStr))
            {
                try
                {
                    oracleConn.Open();
                    log.Info("Oracle 数据库连接成功");

                    mysqlConn.Open();
                    log.Info("MySQL 数据库连接成功");

                    string currentDateStr = "2024-07-01";
                    string queryStr = @"SELECT gch.guestCheckID as guestCheckID, gch.openBusinessDate as busDate,
                   gch.locationID as locationid, gch.revenuecenterid as revenuecenterid,
                gch.checknum AS checkNum, 
                TO_DATE(TO_CHAR(gch.opendatetime, 'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS') AS openDateTime, 
                gch.checktotal AS checkTotal,
                gch.numitems AS numItems, e.firstname AS firstName, e.lastname AS lastName 
                FROM guest_check_hist gch  
                LEFT JOIN employee e ON gch.employeeid=e.employeeid 
                WHERE gch.organizationID =10260 
                   AND gch.locationID = 2041 
                   AND gch.openbusinessdate >= TO_DATE(:currentDateStr, 'YYYY-MM-DD')
                   AND gch.closebusinessdate <= TO_DATE(:currentDateStr, 'YYYY-MM-DD')";

                    var records = oracleConn.Query<GuestCheckHist>(queryStr, new { currentDateStr });

                    if (records == null || records.AsList().Count == 0)
                    {
                        log.Warn("未查询到数据");
                        return;
                    }

                    log.Info($"从 Oracle 获取 {records.AsList().Count} 条记录");

                    string insertQuery = @"INSERT INTO guestcheck 
                  (guestCheckID, busDate, locationid, revenuecenterid, checkNum, openDateTime, checkTotal, numItems, firstName, lastName) 
                  VALUES 
                  (@guestCheckID, @busDate, @locationid, @revenuecenterid, @checkNum, @openDateTime, @checkTotal, @numItems, @firstName, @lastName);";

                    using (var transaction = new TransactionScope())
                    {
                        try
                        {
                            int insertedRows = mysqlConn.Execute(insertQuery, records);
                            log.Info($"成功插入 {insertedRows} 条数据到 MySQL");

                            transaction.Complete();
                        }
                        catch (Exception ex)
                        {
                            log.Error("插入 MySQL 数据失败: " + ex.Message, ex);
                        }
                    }
                }
                catch (OracleException ex)
                {
                    log.Error("Oracle 数据库查询失败: " + ex.Message, ex);
                }
                catch (MySqlException ex)
                {
                    log.Error("MySQL 数据库连接失败: " + ex.Message, ex);
                }
                catch (Exception ex)
                {
                    log.Error("同步数据过程中发生未知错误: " + ex.Message, ex);
                }
                finally
                {
                    if (oracleConn.State == ConnectionState.Open)
                    {
                        oracleConn.Close();
                        log.Info("Oracle 数据库连接关闭");
                    }
                    if (mysqlConn.State == ConnectionState.Open)
                    {
                        mysqlConn.Close();
                        log.Info("MySQL 数据库连接关闭");
                    }
                }
            }
        }
        catch (System.Exception e)
        {
            log.Error(e);
            return;
        }
        log.Info("=== 数据同步完成 ===");
    }
}
